      integer, parameter ::  MPI_INTEGER          =  0
      integer, parameter ::  MPI_REAL             =  1
      integer, parameter ::  MPI_LOGICAL          =  2
      integer, parameter ::  MPI_DOUBLE_PRECISION =  3

      integer, parameter ::  MPI_COMM_WORLD       = 10

      integer, parameter ::  MPI_SUM              = 20
      integer, parameter ::  MPI_STATUS_SIZE      =  4
!     integer, parameter ::  
